#include "Double.h"

double Double::error = 0.00001;