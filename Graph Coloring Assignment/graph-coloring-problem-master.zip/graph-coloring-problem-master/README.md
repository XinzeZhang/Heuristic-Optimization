# graph-coloring-problem
Given m colors, find a way of coloring the vertices of a graph such that no two adjacent vertices are colored using same color
